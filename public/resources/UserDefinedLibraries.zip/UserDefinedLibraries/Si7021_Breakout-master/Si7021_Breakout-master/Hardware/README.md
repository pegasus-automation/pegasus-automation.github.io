SparkFun <PRODUCT NAME> Design Files
=====================================

The .sch and .brd files hare are Eagle CAD schematic and PCB design files from SparkFun Electronics.
A freeware version of Eagle can be found [here](http://www.cadsoftusa.com/download-eagle/freeware/). 


License Information
-------------------

This product is _**open source**_!

Please review the LICENSE.md file for license information.

If you have any questions or concerns on licensing, please contact techsupport@sparkfun.com.

Distributed as-is; no warranty is given.

- Your friends at SparkFun.

_<COLLABORATION CREDIT>_
