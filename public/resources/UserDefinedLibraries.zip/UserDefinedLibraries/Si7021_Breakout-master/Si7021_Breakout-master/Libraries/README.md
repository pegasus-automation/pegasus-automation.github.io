SparkFun HTU21D Libraries
=================================

Libraries for use in different environments.


Directory Contents
-------------------
 Arduino - [Arduino IDE](httpwww.arduino.ccenMainSoftware) libraries


License Information
-------------------

This product is _**open source**_!

Please review the LICENSE.md file for license information.

If you have any questions or concerns on licensing, please contact techsupport@sparkfun.com.

Distributed as-is; no warranty is given.

- Your friends at SparkFun.

_<COLLABORATION CREDIT>_

Update Library Instructions:
----------------------------
To get the most up-to-date version of the library, you must run the following git subtree commands.

$git subtree pull -P Libraries/Arduino --squash https://github.com/sparkfun/SparkFun_HTU21D_Breakout_Arduino_Library.git master
