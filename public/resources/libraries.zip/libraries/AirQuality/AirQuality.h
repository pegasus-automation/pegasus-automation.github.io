#ifndef AirQuality_H
#define AirQuality_H

#include<Wire.h>


 
 class AirQuality{
	 
	 public:
	 AirQuality(void);
	 
	 bool begin(void);
	 uint16_t getCO2();
	 uint16_t getTVOC();
	 
	 
 };
 #endif