#include "Arduino.h"
#include <Wire.h>
#include <AirQuality.h>
#include "SparkFunCCS811.h"

#define CCS811_ADDR 0x5B //Default I2C Address

CCS811 mySensor(CCS811_ADDR);

AirQuality :: AirQuality(void){

}

bool AirQuality :: begin(){
	mySensor.begin();
  
}

uint16_t AirQuality:: getCO2(){
if (mySensor.dataAvailable())
  {
    //If so, have the sensor read and calculate the results.
    //Get them later
    mySensor.readAlgorithmResults();
    return mySensor.getCO2();
   
  }

}

uint16_t AirQuality:: getCO2(){
if (mySensor.dataAvailable())
  {
    //If so, have the sensor read and calculate the results.
    //Get them later
    mySensor.readAlgorithmResults();
    return mySensor.getTVOC();
   
  }

}



