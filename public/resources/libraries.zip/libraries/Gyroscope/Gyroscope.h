#ifndef Gyroscope_H
#define Gyroscope_H

#include<Wire.h>


 
 class Gyroscope{
	 
	 public:
	 Gyroscope(void);
	 
	 bool begin(void);
	 int16_t getX();
	 int16_t getY();
	 int16_t getZ();
	 
 };
 #endif