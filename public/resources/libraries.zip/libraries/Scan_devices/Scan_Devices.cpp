#if ARDUINO >=100
	#include "Arduino.h"
#else
	#include "WProgram.h"
#endif
#include <Wire.h>
#include <Scan_Devices.h>
#include <stdint.h>
Scan_Devices::Scan_Devices()
{

}
int * Scan_Devices::scan()
{

  uint8_t error;
  int address;
  nDevices = 0;
  
  //scan for i2c sensors/actuators
  for (int address = 1 ; address < max_value ; address++ )
  {
    //Check if I2C address is available
    Wire.beginTransmission(address);
    error = Wire.endTransmission(false);
    if (error == 0)   //device is found
    {
      devices[address] = 1;
      nDevices++;
    }
    else
    {
      devices[address] = 0;
    }
  }
  return devices;
}