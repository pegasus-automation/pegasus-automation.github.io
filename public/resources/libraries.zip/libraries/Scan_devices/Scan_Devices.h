#ifndef Scan_Devices_h
#define Scan_Devices_h 
#define max_value 127                //Maximum No. of I2c Address           
class Scan_Devices
{
public:
  Scan_Devices();
  int * scan();

   int nDevices;
   int devices[max_value] = {0};
};
#endif