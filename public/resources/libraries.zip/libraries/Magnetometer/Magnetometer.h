#ifndef Magnetometer_H
#define Magnetometer_H
#define mag_addr 0x1E 
#include <Wire.h>
/*=========================================================================*/

class Magnetometer {
 public:
  Magnetometer(void);
  void begin(void);
  void getaxis();
  int getX();
  int getY();
  int getZ();
};
#endif
