#include <Arduino.h>
#include <Magnetometer.h>
#include <Wire.h>

Magnetometer::Magnetometer(void)
{

}
void Magnetometer::begin()
{
	Serial.begin(9600);
	Wire.begin();
	Wire.beginTransmission(mag_addr); //open communication with HMC5883
	Serial.println("AAGAMMAMAMAMAMA");
	Wire.write(0x02); //select mode register
	Wire.write(0x00); //continuous measurement mode
	Serial.println("AAGAMMAMAMAMAMA1111");
Serial.flush();
	//Wire.endTransmission(false);
	Serial.println("####");
Serial.flush();
}

void Magnetometer::getaxis()
{
	Wire.beginTransmission(mag_addr);
	Wire.write(0x03); //select register 3, X MSB register
	//Wire.endTransmission();

	//Read data from each axis, 2 registers per axis
	int x,y,z;
	Serial.println("mdbvifvdc");
	Wire.requestFrom(mag_addr, 6);
	Serial.println("mdbvifvdc");
	if (6 <= Wire.available())
	{
	  	x = Wire.read() << 8; //X msb
	  	x |= Wire.read(); 	//X lsb
	  	z = Wire.read() << 8; //Z msb
	  	z |= Wire.read(); 	//Z lsb
	  	y = Wire.read() << 8; //Y msb
	  	y |= Wire.read(); 	//Y lsb
	}
	Serial.println(x);
	Serial.println(y);
	Serial.println(z);
	Serial.println();
	Serial.flush();
	delay(1000);
}
int Magnetometer::getX()
{
	Wire.beginTransmission(mag_addr);
	Wire.write(0x03); //select register 3, X MSB register
	//Wire.endTransmission(false);


	int x,y,z;
	//Read data from each axis, 2 registers per axis
	Serial.println("cvdcyudv cjdv ");
Serial.flush();
	Wire.requestFrom(mag_addr, 6);
Serial.println("cvdcyudv cjdv1111 ");
Serial.flush();
	if (6 <= Wire.available())
	{
  	x = Wire.read() << 8; //X msb
  	x |= Wire.read(); 	//X lsb
  	z = Wire.read() << 8; //Z msb
  	z |= Wire.read(); 	//Z lsb
  	y = Wire.read() << 8; //Y msb
  	y |= Wire.read(); 	//Y lsb
	}
	return x;
}

int Magnetometer::getY()
{
	Wire.beginTransmission(mag_addr);
	Wire.write(0x03); //select register 3, X MSB register
	Wire.endTransmission(false);


	int x,y,z;
	//Read data from each axis, 2 registers per axis
	Wire.requestFrom(mag_addr, 6);
	if (6 <= Wire.available())
	{
  	x = Wire.read() << 8; //X msb
  	x |= Wire.read(); 	//X lsb
  	z = Wire.read() << 8; //Z msb
  	z |= Wire.read(); 	//Z lsb
  	y = Wire.read() << 8; //Y msb
  	y |= Wire.read(); 	//Y lsb
	}
	return y;
}

int Magnetometer::getZ()
{
	Wire.beginTransmission(mag_addr);
	Wire.write(0x03); //select register 3, X MSB register
	Wire.endTransmission(false);


	//Read data from each axis, 2 registers per axis
	int x,y,z;
	Wire.requestFrom(mag_addr, 6);
	if (6 <= Wire.available())
	{
	  	x = Wire.read() << 8; //X msb
	  	x |= Wire.read(); 	//X lsb
	  	z = Wire.read() << 8; //Z msb
	  	z |= Wire.read(); 	//Z lsb
	  	y = Wire.read() << 8; //Y msb
	  	y |= Wire.read(); 	//Y lsb
	}
	return z;
}
