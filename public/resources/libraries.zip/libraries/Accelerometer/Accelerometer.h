#ifndef Accelerometer_H
#define Accelerometer_H

#include<Wire.h>


 
 class Accelerometer{
	 
	 public:
	 Accelerometer(void);
	 
	 bool begin(void);
	 int16_t getX();
	 int16_t getY();
	 int16_t getZ();
	 
 };
 #endif