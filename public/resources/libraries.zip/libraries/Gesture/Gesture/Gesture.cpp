#include "Arduino.h"
#include <Wire.h>
#include <Gesture.h>
#include <SparkFun_APDS9960.h>

SparkFun_APDS9960 apds = SparkFun_APDS9960();


Gesture :: Gesture(void){

}

bool Gesture :: begin(){
	
  apds.init();
  apds.enableGestureSensor(true);
}

int Gesture :: getGesture(){
	while(1){
  if ( apds.isGestureAvailable() ) {
    switch ( apds.readGesture() ) {
      case DIR_UP:
		
        return 1;
		
        break;
      case DIR_DOWN:
        return 2;
		
        break;
      case DIR_LEFT:
        return 3;
		
        break;
      case DIR_RIGHT:
        return 4;
		break;
      case DIR_NEAR:
        return 5;
		
        break;
      case DIR_FAR:
        return 6;
		
        break;
      default:
        return 7;
		
    }
  }
}
}

