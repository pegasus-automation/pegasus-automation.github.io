#ifndef Gesture_H
#define Gesture_H

#include<Wire.h>


 
 class Gesture{
	 
	 public:
	 Gesture(void);
	 
	 bool begin(void);
	 int getGesture(void);
	 
 };
 #endif