#ifndef RGB_H
#define RGB_H

#include<Wire.h>


 
 class RGB{
	 
	 public:
	 RGB(void);
	 
	 bool begin(void);
	 uint16_t getAmbient(void);
	 uint16_t getRed(void);
	 uint16_t getGreen(void);
	 uint16_t getBlue(void);
	 
 };
 #endif