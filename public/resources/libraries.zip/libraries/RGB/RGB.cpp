#include "Arduino.h"
#include <Wire.h>
#include <RGB.h>
#include <SparkFun_APDS9960.h>

SparkFun_APDS9960 apds = SparkFun_APDS9960();

uint16_t ambient_light = 0;
uint16_t red_light = 0;
uint16_t green_light = 0;
uint16_t blue_light = 0;

RGB :: RGB(void){
Serial.begin(9600);
}


bool RGB :: begin(){
	
  apds.init();
   apds.enableLightSensor(false);
  apds.setProximityGain(PGAIN_2X);
  apds.enableProximitySensor(false);
}

uint16_t RGB :: getAmbient(){
	apds.readAmbientLight(ambient_light);
	Serial.println(ambient_light);
	return ambient_light;
}

uint16_t RGB :: getRed(){
	apds.readRedLight(red_light);
	return red_light;
}

uint16_t RGB :: getGreen(){
	apds.readGreenLight(green_light);
	return green_light;
}

uint16_t RGB :: getBlue(){
	apds.readBlueLight(blue_light);
	return blue_light;
}

