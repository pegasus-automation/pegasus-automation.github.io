#include <Wire.h>
#include <Luminosity.h>
#include <math.h>
Luminosity::Luminosity()
{

}

void Luminosity::begin()
{
  Wire.begin();
  Wire.beginTransmission(Addr);
  Wire.write(0x00 | 0x80);
  Wire.write(0x03);
  Wire.endTransmission();
  Wire.beginTransmission(Addr);
  Wire.write(0x01 | 0x80);
  Wire.write(0x02);
  Wire.endTransmission();
  //delay(300);
 }

double Luminosity::getInfraRed()
{
	unsigned int data[4];
  for(int i = 0; i < 4; i++)
  {
    Wire.beginTransmission(Addr);
    Wire.write((140 + i));
    Wire.endTransmission();
    Wire.requestFrom(Addr, 1);
    if(Wire.available() == 1)
    {
      data[i] = Wire.read();
    }
     //delay(500);
  }
  double ch0 = ((data[1] & 0xFF) * 256) + (data[0] & 0xFF);
  double ch1 = ((data[3] & 0xFF) * 256) + (data[2] & 0xFF);
  double Lux_value = 0;
  if(0 < ch1/ch0 <= 0.52)
  {
    Lux_value = 0.0315 * ch0 - 0.0593 * ch0 * pow((ch1/ch0),0.25);
  }
  else if(0.52 < ch1/ch0 <= 0.65)
  {
    Lux_value = 0.0229 * ch0 - 0.0291 * ch1;
  }
  else if(0.65 < ch1/ch0 <= 0.80)
  {
    Lux_value = 0.0157 * ch0 - 0.0180 * ch1;
  }
  else if(0.80 < ch1/ch0 <= 1.30)
  {
    Lux_value = 0.00338 * ch0 - 0.00260 * ch1;
  }
  else if(ch1/ch0 > 1.30)
  {
    Lux_value = 0;
  }

return ch1;
}


double Luminosity::getVisibleValue(){
  unsigned int data[4];
  for(int i = 0; i < 4; i++)
  {
    Wire.beginTransmission(Addr);
    Wire.write((140 + i));
    Wire.endTransmission();
    Wire.requestFrom(Addr, 1);
    if(Wire.available() == 1)
    {
      data[i] = Wire.read();
    }
     //delay(500);
  }
  double ch0 = ((data[1] & 0xFF) * 256) + (data[0] & 0xFF);
  double ch1 = ((data[3] & 0xFF) * 256) + (data[2] & 0xFF);
  double Lux_value = 0;
  if(0 < ch1/ch0 <= 0.52)
  {
    Lux_value = 0.0315 * ch0 - 0.0593 * ch0 * pow((ch1/ch0),0.25);
  }
  else if(0.52 < ch1/ch0 <= 0.65)
  {
    Lux_value = 0.0229 * ch0 - 0.0291 * ch1;
  }
  else if(0.65 < ch1/ch0 <= 0.80)
  {
    Lux_value = 0.0157 * ch0 - 0.0180 * ch1;
  }
  else if(0.80 < ch1/ch0 <= 1.30)
  {
    Lux_value = 0.00338 * ch0 - 0.00260 * ch1;
  }
  else if(ch1/ch0 > 1.30)
  {
    Lux_value = 0;
  }

  return (ch0-ch1);


}
double Luminosity::getIlluminance(){
		unsigned int data[4];
  for(int i = 0; i < 4; i++)
  {
    Wire.beginTransmission(Addr);
    Wire.write((140 + i));
    Wire.endTransmission();
    Wire.requestFrom(Addr, 1);
    if(Wire.available() == 1)
    {
      data[i] = Wire.read();
    }
     //delay(500);
  }
  double ch0 = ((data[1] & 0xFF) * 256) + (data[0] & 0xFF);
  double ch1 = ((data[3] & 0xFF) * 256) + (data[2] & 0xFF);
  double Lux_value = 0;
  if(0 < ch1/ch0 <= 0.52)
  {
    Lux_value = 0.0315 * ch0 - 0.0593 * ch0 * pow((ch1/ch0),0.25);
  }
  else if(0.52 < ch1/ch0 <= 0.65)
  {
    Lux_value = 0.0229 * ch0 - 0.0291 * ch1;
  }
  else if(0.65 < ch1/ch0 <= 0.80)
  {
    Lux_value = 0.0157 * ch0 - 0.0180 * ch1;
  }
  else if(0.80 < ch1/ch0 <= 1.30)
  {
    Lux_value = 0.00338 * ch0 - 0.00260 * ch1;
  }
  else if(ch1/ch0 > 1.30)
  {
    Lux_value = 0;
  }

  return Lux_value;


}
