#ifndef Luminosity_h
#define Luminosity_h
#define Addr 0x29
class Luminosity
{
public:
	Luminosity();
	void begin();
	double getInfraRed();
	double getVisibleValue();
	double getIlluminance();
};
#endif
