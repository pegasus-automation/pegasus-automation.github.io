#ifndef RTC_H
#define RTC_H
#include <Wire.h>


 
 class RTC{
	 
	 public:
		RTC(void);
		bool begin();
		int getSecond();
		int getMinute();
		int getHour();
		int getWeekday();
		int getMonthday();
		int getMonth();
		int getYear();
		
		
	private:
		byte bcdToDec(byte);
	
 };
 #endif